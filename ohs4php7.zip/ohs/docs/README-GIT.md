# git Access

PKP provides access via github to the latest OHS code.

git web interface: https://github.com/pkp/harvester

Read-only git access: git://github.com/pkp/harvester.git

Please consult https://pkp.sfu.ca/wiki/index.php/HOW-TO_check_out_PKP_applications_from_git
for instructions on setting up a development environment.

Note that you must rename `config.TEMPLATE.inc.php` to `config.inc.php` prior to
running the OHS installation script.
