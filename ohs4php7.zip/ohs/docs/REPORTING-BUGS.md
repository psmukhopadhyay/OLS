## Reporting Bugs

Bugs can be reported through Git issues at:
https://github.com/pkp/pkp-lib#issues

## Support Forum

A user support forum for PKP software is located at:
https://forum.pkp.sfu.ca/

## Email

OHS or general PKP inquiries: <pkp.contact@gmail.com>
