<?php return array (
  'plugins.generic.sehl.name' => 'SEHL Plugin',
  'plugins.generic.sehl.description' => 'This plugin implements Search Engine HighLighting (SEHL) so that when a search engine locates a record, the sought-after keywords are highlighted.',
); ?>