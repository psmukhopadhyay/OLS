<?php /* Smarty version 2.6.31, created on 2021-06-24 14:21:31
         compiled from install/install.tpl */ ?>
<?php echo ''; ?><?php $this->assign('pageTitle', "installer.harvester2Installation"); ?><?php echo ''; ?><?php $this->assign('skipFilesDirSection', 1); ?><?php echo ''; ?><?php $this->assign('skipMiscSettings', 1); ?><?php echo ''; ?><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "core:install/install.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><?php echo ''; ?>