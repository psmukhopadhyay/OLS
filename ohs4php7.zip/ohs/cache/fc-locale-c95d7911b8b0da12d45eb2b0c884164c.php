<?php return array (
  'plugins.generic.tinymce.name' => 'TinyMCE Plugin',
  'plugins.generic.tinymce.description' => 'This plugin enables WYSIWYG editing of textareas using the <a href="http://tinymce.moxiecode.com" target="_new">TinyMCE</a> content editor.',
  'plugins.generic.tinymce.descriptionDisabled' => 'This plugin enables WYSIWYG editing of OHS textareas using the <a href="http://tinymce.moxiecode.com" target="_new">TinyMCE</a> content editor. <strong>TinyMCE is not currently installed; please install it in {$tinyMcePath}.</strong>',
  'plugins.generic.tinymce.settings' => 'Settings',
); ?>