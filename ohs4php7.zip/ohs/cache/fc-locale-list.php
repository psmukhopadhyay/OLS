<?php return array (
  'en_US' => 
  array (
    'key' => 'en_US',
    'name' => 'English',
  ),
  'tr_TR' => 
  array (
    'key' => 'tr_TR',
    'name' => 'Türkçe',
  ),
); ?>