<?php
	$sal_version = "0.9";
?>
